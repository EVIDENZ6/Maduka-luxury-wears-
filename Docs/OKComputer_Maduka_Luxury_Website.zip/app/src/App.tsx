import { useEffect, useRef } from 'react';
import HeroSection from './sections/HeroSection';
import PinnedSection from './sections/PinnedSection';
import ContactSection from './sections/ContactSection';
import WhatsAppButton from './components/WhatsAppButton';

// Section data for pinned sections 2-8
const pinnedSectionsData = [
  {
    id: 'section-define-style',
    headline: 'DEFINE YOUR',
    headlineLine2: 'STYLE',
    body: 'Fit, fabric, and finish—crafted for those who lead.',
    cta: 'See the Craft',
    imageSrc: '/images/style_define_portrait.jpg',
    zIndex: 20,
  },
  {
    id: 'section-be-trend',
    headline: 'BE THE',
    headlineLine2: 'TREND',
    body: 'Modern cuts. Timeless discipline. Wear the future.',
    cta: 'View Lookbook',
    imageSrc: '/images/trend_portrait.jpg',
    zIndex: 30,
  },
  {
    id: 'section-your-style',
    headline: 'YOUR STYLE,',
    headlineLine2: 'YOUR WAY',
    body: 'From boardrooms to celebrations—tailored to your rhythm.',
    cta: 'Build Your Fit',
    imageSrc: '/images/your_style_portrait.jpg',
    zIndex: 40,
  },
  {
    id: 'section-speaks',
    headline: 'FASHION THAT',
    headlineLine2: 'SPEAKS',
    body: 'Silence the noise. Let your presence do the talking.',
    cta: 'Read Our Story',
    imageSrc: '/images/speaks_portrait.jpg',
    zIndex: 50,
  },
  {
    id: 'section-ahead',
    headline: 'STAY',
    headlineLine2: 'AHEAD',
    body: 'Anticipate the moment. Arrive prepared.',
    cta: 'Join the List',
    imageSrc: '/images/ahead_portrait.jpg',
    zIndex: 60,
  },
  {
    id: 'section-impress',
    headline: 'DRESS TO',
    headlineLine2: 'IMPRESS',
    body: 'First impressions are stitched long before the handshake.',
    cta: 'Book a Fitting',
    imageSrc: '/images/impress_portrait.jpg',
    zIndex: 70,
  },
  {
    id: 'section-eternal',
    headline: 'STYLE IS',
    headlineLine2: 'ETERNAL',
    body: 'Trends fade. Craft remains. Own the legacy.',
    cta: 'Shop the Collection',
    imageSrc: '/images/eternal_portrait.jpg',
    zIndex: 80,
  },
];

function App() {
  const mainRef = useRef<HTMLElement>(null);
  const isScrollingRef = useRef(false);
  const scrollTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    // Global scroll snap for pinned sections
    const pinnedSectionIds = ['section-hero', ...pinnedSectionsData.map(s => s.id)];
    const sections = pinnedSectionIds.map(id => document.getElementById(id)).filter(Boolean) as HTMLElement[];
    
    const handleScroll = () => {
      if (isScrollingRef.current) return;
      
      // Clear existing timeout
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
      
      // Set new timeout for snap
      scrollTimeoutRef.current = setTimeout(() => {
        const scrollY = window.scrollY;
        const viewportHeight = window.innerHeight;
        
        // Find which section we're in
        for (const section of sections) {
          const rect = section.getBoundingClientRect();
          const sectionTop = rect.top + scrollY;
          const sectionHeight = rect.height;
          
          // Check if we're within this section's bounds
          if (scrollY >= sectionTop - viewportHeight * 0.3 && 
              scrollY < sectionTop + sectionHeight - viewportHeight * 0.3) {
            
            // Calculate how far through the section we are
            const progress = (scrollY - sectionTop + viewportHeight * 0.3) / sectionHeight;
            
            // If we're in the entrance or exit zones, snap to settle
            if (progress < 0.25) {
              // Snap to settle center
              isScrollingRef.current = true;
              const settleTarget = sectionTop + sectionHeight * 0.5 - viewportHeight * 0.5;
              window.scrollTo({
                top: settleTarget,
                behavior: 'smooth'
              });
              setTimeout(() => {
                isScrollingRef.current = false;
              }, 500);
              break;
            } else if (progress > 0.75 && progress < 1) {
              // Near exit - let it scroll naturally to next section
              break;
            }
          }
        }
      }, 150);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
    };
  }, []);

  // Keyboard navigation
  useEffect(() => {
    const sectionIds = ['section-hero', ...pinnedSectionsData.map(s => s.id), 'contact'];
    
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        const viewportHeight = window.innerHeight;
        
        // Find current section
        let currentIndex = 0;
        for (let i = 0; i < sectionIds.length; i++) {
          const section = document.getElementById(sectionIds[i]);
          if (section) {
            const rect = section.getBoundingClientRect();
            if (rect.top <= viewportHeight * 0.5 && rect.bottom > viewportHeight * 0.5) {
              currentIndex = i;
              break;
            }
          }
        }
        
        let nextIndex = currentIndex;
        if (e.key === 'ArrowDown' && currentIndex < sectionIds.length - 1) {
          nextIndex = currentIndex + 1;
        } else if (e.key === 'ArrowUp' && currentIndex > 0) {
          nextIndex = currentIndex - 1;
        }
        
        if (nextIndex !== currentIndex) {
          const nextSection = document.getElementById(sectionIds[nextIndex]);
          if (nextSection) {
            nextSection.scrollIntoView({ behavior: 'smooth' });
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <>
      {/* Grain Overlay */}
      <div className="grain-overlay" />
      
      {/* Main Content */}
      <main ref={mainRef} className="relative">
        {/* Hero Section */}
        <HeroSection />
        
        {/* Pinned Statement Sections */}
        {pinnedSectionsData.map((section) => (
          <PinnedSection
            key={section.id}
            {...section}
          />
        ))}
        
        {/* Contact Section (Flowing) */}
        <ContactSection />
      </main>
      
      {/* Floating WhatsApp Button */}
      <WhatsAppButton />
    </>
  );
}

export default App;
