import { useEffect, useRef, useState } from 'react';
import { Mail, Phone, MapPin, Clock, Instagram, Twitter, ArrowRight, MessageCircle } from 'lucide-react';

export default function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [newsletterEmail, setNewsletterEmail] = useState('');

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible(true);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );

    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thank you for your inquiry. We will contact you soon.');
    setFormData({ name: '', email: '', message: '' });
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thank you for subscribing to our newsletter!');
    setNewsletterEmail('');
  };

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="relative min-h-screen py-20"
      style={{ backgroundColor: '#F4F1EA', zIndex: 100 }}
    >
      <div className="max-w-[90vw] mx-auto px-[4.5vw]">
        {/* Top Section - Headline + Contact Card */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-20">
          {/* Left - Headline */}
          <div 
            className={`transition-all duration-800 ease-out ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-20'
            }`}
          >
            <h2 
              className="text-[5vw] leading-[0.92] text-[#0B0B0D] mb-6"
              style={{ fontWeight: 800 }}
            >
              START YOUR
              <br />
              JOURNEY
            </h2>
            <p className="text-lg text-[#0B0B0D]/70 leading-relaxed max-w-md">
              Tell us what you need. We&apos;ll handle the details.
            </p>
          </div>

          {/* Right - Contact Card */}
          <div 
            className={`transition-all duration-800 delay-200 ease-out ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'
            }`}
          >
            <div className="bg-white rounded-lg p-8 shadow-lg">
              <div className="space-y-5">
                <div className="flex items-center gap-4">
                  <Mail className="w-5 h-5 text-[#C9A45C]" strokeWidth={1.5} />
                  <span className="text-[#0B0B0D] font-medium">hello@madukaluxury.com</span>
                </div>
                <div className="flex items-center gap-4">
                  <Phone className="w-5 h-5 text-[#C9A45C]" strokeWidth={1.5} />
                  <span className="text-[#0B0B0D] font-medium">+234 901 629 5356</span>
                </div>
                <a 
                  href="https://wa.me/2349016295356?text=Hello%20MLW!%20I'm%20interested%20in%20your%20luxury%20collection."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 group"
                >
                  <MessageCircle className="w-5 h-5 text-[#25D366]" strokeWidth={1.5} />
                  <span className="text-[#0B0B0D] font-medium group-hover:text-[#25D366] transition-colors">Chat on WhatsApp</span>
                </a>
                <div className="flex items-center gap-4">
                  <MapPin className="w-5 h-5 text-[#C9A45C]" strokeWidth={1.5} />
                  <span className="text-[#0B0B0D] font-medium">Lagos, Nigeria</span>
                </div>
                <div className="flex items-center gap-4">
                  <Clock className="w-5 h-5 text-[#C9A45C]" strokeWidth={1.5} />
                  <span className="text-[#0B0B0D] font-medium">Showroom: Mon–Sat, 10am–7pm</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Form Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Left - Inquiry Form */}
          <div 
            className={`transition-all duration-800 delay-300 ease-out ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
          >
            <h3 className="text-xl font-semibold text-[#0B0B0D] mb-6 uppercase tracking-wide">
              Send Inquiry
            </h3>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-[#0B0B0D]/70 mb-2 uppercase tracking-wider">
                  Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 bg-white border border-[#0B0B0D]/10 rounded-md text-[#0B0B0D] focus:outline-none focus:ring-2 focus:ring-[#C9A45C] focus:border-transparent transition-all"
                  placeholder="Your name"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0B0B0D]/70 mb-2 uppercase tracking-wider">
                  Email
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3 bg-white border border-[#0B0B0D]/10 rounded-md text-[#0B0B0D] focus:outline-none focus:ring-2 focus:ring-[#C9A45C] focus:border-transparent transition-all"
                  placeholder="your@email.com"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0B0B0D]/70 mb-2 uppercase tracking-wider">
                  Message
                </label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  rows={4}
                  className="w-full px-4 py-3 bg-white border border-[#0B0B0D]/10 rounded-md text-[#0B0B0D] focus:outline-none focus:ring-2 focus:ring-[#C9A45C] focus:border-transparent transition-all resize-none"
                  placeholder="Tell us about your needs..."
                  required
                />
              </div>
              <button
                type="submit"
                className="btn-primary flex items-center gap-2"
              >
                Send Inquiry
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>

          {/* Right - Newsletter */}
          <div 
            className={`transition-all duration-800 delay-400 ease-out ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
          >
            <h3 className="text-xl font-semibold text-[#0B0B0D] mb-6 uppercase tracking-wide">
              Join the List
            </h3>
            <p className="text-[#0B0B0D]/70 mb-6">
              Subscribe for exclusive drops, invites, and behind-the-scenes access.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-[#0B0B0D]/70 mb-2 uppercase tracking-wider">
                  Email
                </label>
                <input
                  type="email"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  className="w-full px-4 py-3 bg-white border border-[#0B0B0D]/10 rounded-md text-[#0B0B0D] focus:outline-none focus:ring-2 focus:ring-[#C9A45C] focus:border-transparent transition-all"
                  placeholder="your@email.com"
                  required
                />
              </div>
              <button
                type="submit"
                className="btn-primary"
              >
                Subscribe
              </button>
            </form>

            {/* Social Links */}
            <div className="mt-12 pt-8 border-t border-[#0B0B0D]/10">
              <p className="text-sm text-[#0B0B0D]/50 mb-4 uppercase tracking-wider">Connect With Us</p>
              <div className="flex items-center gap-4">
                <a 
                  href="#" 
                  className="w-10 h-10 rounded-full bg-[#0B0B0D] flex items-center justify-center hover:bg-[#C9A45C] transition-colors"
                >
                  <Instagram className="w-5 h-5 text-white" strokeWidth={1.5} />
                </a>
                <a 
                  href="#" 
                  className="w-10 h-10 rounded-full bg-[#0B0B0D] flex items-center justify-center hover:bg-[#C9A45C] transition-colors"
                >
                  <Twitter className="w-5 h-5 text-white" strokeWidth={1.5} />
                </a>
                <a 
                  href="https://wa.me/2349016295356?text=Hello%20MLW!%20I'm%20interested%20in%20your%20luxury%20collection."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-[#25D366] flex items-center justify-center hover:bg-[#128C7E] transition-colors"
                >
                  <MessageCircle className="w-5 h-5 text-white fill-white" strokeWidth={1.5} />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-20 pt-8 border-t border-[#0B0B0D]/10">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="font-mono-label text-[#C9A45C] tracking-widest">MLW</span>
              <span className="text-[#0B0B0D]/50 text-sm">|</span>
              <span className="text-[#0B0B0D]/50 text-sm">Maduka Luxury Wears</span>
            </div>
            <div className="flex items-center gap-6">
              <a href="#" className="text-[#0B0B0D]/50 text-sm hover:text-[#0B0B0D] transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-[#0B0B0D]/50 text-sm hover:text-[#0B0B0D] transition-colors">
                Terms of Service
              </a>
            </div>
            <p className="text-[#0B0B0D]/50 text-sm">
              © 2026 Maduka Luxury Wears. All rights reserved.
            </p>
          </div>
        </footer>
      </div>
    </section>
  );
}
