import { useEffect, useRef, useState } from 'react';
import { ChevronDown, ShoppingBag, MessageCircle } from 'lucide-react';

export default function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // Trigger entrance animation after mount
    const timer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const scrollToNext = () => {
    const nextSection = document.getElementById('section-define-style');
    if (nextSection) {
      nextSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="section-hero"
      className="section-pinned z-10"
    >
      {/* Background Image */}
      <div 
        className={`absolute inset-0 transition-all duration-1000 ease-out ${
          isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
        }`}
      >
        <img
          src="/images/hero_portrait.jpg"
          alt="Maduka Luxury Wears"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Gradient Overlay */}
      <div 
        className={`absolute inset-0 gradient-overlay transition-opacity duration-1000 ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        }`}
      />

      {/* MLW Logo - Top Left */}
      <div 
        className={`absolute left-[4.5vw] top-[5vh] z-20 transition-all duration-700 ease-out ${
          isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-5'
        }`}
      >
        <span className="font-mono-label mlw-gold tracking-widest text-sm">MLW</span>
      </div>

      {/* Menu Button - Top Right */}
      <div 
        className={`absolute right-[4.5vw] top-[5vh] z-20 flex items-center gap-6 transition-all duration-700 ease-out ${
          isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-5'
        }`}
      >
        <button className="font-mono-label text-white hover:text-[#C9A45C] transition-colors text-sm">
          MENU
        </button>
        <button className="relative">
          <ShoppingBag className="w-5 h-5 text-[#C9A45C]" strokeWidth={1.5} />
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#C9A45C] text-[#0B0B0D] text-[10px] font-bold rounded-full flex items-center justify-center">
            0
          </span>
        </button>
      </div>

      {/* Content Block - Left Side */}
      <div className="absolute left-[4.5vw] top-0 h-full flex flex-col justify-center z-20 max-w-[42vw]">
        {/* Micro Label */}
        <div 
          className={`transition-all duration-700 delay-200 ease-out ${
            isLoaded ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'
          }`}
        >
          <span className="font-mono-label text-[#B8B2AA] tracking-[0.2em]">
            MADUKA LUXURY WEARS
          </span>
        </div>

        {/* Main Headline */}
        <h1 
          className={`text-[12vw] leading-[0.88] text-white mt-4 transition-all duration-800 delay-300 ease-out ${
            isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
          style={{ fontWeight: 900 }}
        >
          MLW
        </h1>

        {/* Subheadline */}
        <p 
          className={`text-[2.2vw] text-white/90 mt-8 font-light tracking-wide transition-all duration-700 delay-500 ease-out ${
            isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          Luxury in Every Stitch.
        </p>

        {/* CTA Buttons */}
        <div 
          className={`flex flex-col items-start gap-5 mt-10 transition-all duration-700 delay-600 ease-out ${
            isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          <a 
            href="https://wa.me/2349016295356?text=Hello%20MLW!%20I'm%20interested%20in%20your%20luxury%20collection."
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary flex items-center gap-3"
          >
            <MessageCircle className="w-5 h-5" />
            Shop via WhatsApp
          </a>
          <a href="#contact" className="link-underline">
            Book a Fitting
          </a>
        </div>
      </div>

      {/* Scroll Cue - Bottom Right */}
      <button 
        onClick={scrollToNext}
        className={`absolute right-[4.5vw] bottom-[6vh] z-20 flex flex-col items-center gap-2 group transition-all duration-700 delay-700 ease-out ${
          isLoaded ? 'opacity-70 translate-y-0' : 'opacity-0 translate-y-3'
        } hover:opacity-100`}
      >
        <span className="font-mono-label text-white text-xs tracking-[0.2em]">SCROLL</span>
        <ChevronDown className="w-4 h-4 text-white group-hover:translate-y-1 transition-transform" strokeWidth={1.5} />
      </button>
    </section>
  );
}
