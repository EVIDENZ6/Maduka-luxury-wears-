import { useEffect, useRef } from 'react';

interface PinnedSectionProps {
  id: string;
  headline: string;
  headlineLine2?: string;
  body: string;
  cta: string;
  imageSrc: string;
  zIndex: number;
}

export default function PinnedSection({
  id,
  headline,
  headlineLine2,
  body,
  cta,
  imageSrc,
  zIndex,
}: PinnedSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;
    const image = imageRef.current;
    if (!section || !content || !image) return;

    const observerOptions = {
      root: null,
      rootMargin: '0px',
      threshold: [0, 0.15, 0.3, 0.5, 0.7, 0.85, 1],
    };

    const handleIntersect = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        const ratio = entry.intersectionRatio;

        // Content animations based on scroll position
        if (ratio < 0.15) {
          // Before entering - content hidden below
          content.style.opacity = '0';
          content.style.transform = 'translateY(60px)';
          image.style.transform = 'scale(1.1) translateX(-6vw)';
          image.style.opacity = '0.8';
        } else if (ratio >= 0.15 && ratio < 0.3) {
          // Entering phase
          const progress = (ratio - 0.15) / 0.15;
          content.style.opacity = String(progress);
          content.style.transform = `translateY(${60 - progress * 60}px)`;
          image.style.transform = `scale(${1.1 - progress * 0.1}) translateX(${-6 + progress * 6}vw)`;
          image.style.opacity = String(0.8 + progress * 0.2);
        } else if (ratio >= 0.3 && ratio < 0.7) {
          // Settle phase - fully visible
          content.style.opacity = '1';
          content.style.transform = 'translateY(0)';
          image.style.transform = 'scale(1) translateX(0)';
          image.style.opacity = '1';
        } else if (ratio >= 0.7 && ratio < 0.95) {
          // Exiting phase
          const progress = (ratio - 0.7) / 0.25;
          content.style.opacity = String(1 - progress * 0.7);
          content.style.transform = `translateX(${-progress * 18}vw) translateY(${-progress * 10}vh)`;
          image.style.transform = `scale(${1 + progress * 0.06}) translateX(${progress * 4}vw)`;
        } else {
          // Almost gone
          content.style.opacity = '0';
          image.style.opacity = '1';
        }
      });
    };

    const observer = new IntersectionObserver(handleIntersect, observerOptions);
    observer.observe(section);

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id={id}
      className="section-pinned"
      style={{ zIndex }}
    >
      {/* Background Image */}
      <div 
        ref={imageRef}
        className="absolute inset-0 transition-all duration-100 ease-linear will-change-transform"
        style={{ transform: 'scale(1.1) translateX(-6vw)', opacity: 0.8 }}
      >
        <img
          src={imageSrc}
          alt={headline}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Gradient Overlay */}
      <div className="absolute inset-0 gradient-overlay" />

      {/* Content Block - Left Side */}
      <div 
        ref={contentRef}
        className="absolute left-[4.5vw] top-0 h-full flex flex-col justify-center z-10 max-w-[46vw] transition-all duration-100 ease-linear will-change-transform"
        style={{ opacity: 0, transform: 'translateY(60px)' }}
      >
        {/* Headline */}
        <h2 
          className="text-[5.5vw] leading-[0.92] text-white"
          style={{ fontWeight: 800 }}
        >
          {headline}
          {headlineLine2 && (
            <>
              <br />
              {headlineLine2}
            </>
          )}
        </h2>

        {/* Body */}
        <p 
          className="text-[1.1vw] text-[#B8B2AA] mt-8 leading-relaxed max-w-[34vw]"
        >
          {body}
        </p>

        {/* CTA */}
        <div className="mt-10">
          <button className="btn-primary">
            {cta}
          </button>
        </div>
      </div>
    </section>
  );
}
